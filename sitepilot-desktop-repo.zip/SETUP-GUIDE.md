# SitePilot — Complete Setup Guide

Everything you need to go from zero to selling SitePilot. No terminal required for most steps.

---

## Part 1: Deploy the License API (Cloudflare Worker)

This is a tiny API that validates license keys. It runs free on Cloudflare.

### Step 1: Create a Cloudflare account
1. Go to https://dash.cloudflare.com/sign-up
2. Sign up (free)

### Step 2: Create a KV Namespace (your license database)
1. In the Cloudflare dashboard, go to **Workers & Pages** > **KV**
2. Click **Create a namespace**
3. Name it `sitepilot-licenses`
4. Click **Add**
5. Copy the **Namespace ID** — you'll need it in Step 4

### Step 3: Create the Worker
1. Go to **Workers & Pages** > **Create**
2. Click **Create Worker**
3. Name it `sitepilot-api`
4. Click **Deploy** (this creates a placeholder)
5. Click **Edit code**
6. Delete the placeholder code
7. Paste the entire contents of `sitepilot-api/worker.js`
8. Click **Deploy**

### Step 4: Configure the Worker
1. Go to your Worker > **Settings** > **Bindings**
2. Click **Add** > **KV Namespace**
   - Variable name: `LICENSES`
   - KV Namespace: select `sitepilot-licenses`
   - Click **Save**
3. Go to **Settings** > **Variables and Secrets**
4. Add these variables:
   - `ADMIN_SECRET` = (generate a long random string — this is for admin API access)
   - `STRIPE_WEBHOOK_SECRET` = (you'll get this from Stripe in Part 2)
5. Click **Save and deploy**

### Step 5: Note your Worker URL
Your license API is now live at:
`https://sitepilot-api.YOUR-SUBDOMAIN.workers.dev`

Test it by visiting that URL in a browser — you should see `{"error":"Not found"}` which means it's working.

---

## Part 2: Set Up Stripe Payments

### Step 1: Create Stripe account
1. Go to https://dashboard.stripe.com/register
2. Complete setup

### Step 2: Create your products
1. In Stripe Dashboard > **Products** > **Add product**

**Product 1: SitePilot Single Site**
- Name: SitePilot — Single Site
- Pricing: One-time, $XX (your price)
- Click **Save**

**Product 2: SitePilot Unlimited**
- Name: SitePilot — Unlimited Sites
- Pricing: Recurring, $XX/year
- Click **Save**

### Step 3: Create Payment Links
1. Go to **Payment Links** > **Create payment link**
2. Select your Single Site product
3. Under **After payment**, check "Collect email address"
4. Click **Advanced** > **Custom metadata**:
   - Key: `plan`
   - Value: `single`
5. Click **Create link** — save this URL

Repeat for the Unlimited product, but set metadata `plan` = `unlimited`

### Step 4: Set up the Webhook
1. Go to **Developers** > **Webhooks**
2. Click **Add endpoint**
3. Endpoint URL: `https://sitepilot-api.YOUR-SUBDOMAIN.workers.dev/api/stripe/webhook`
4. Events to listen to:
   - `checkout.session.completed`
   - `invoice.paid`
5. Click **Add endpoint**
6. Click **Reveal signing secret** — copy the `whsec_...` value
7. Go back to Cloudflare Worker > Settings > Variables
8. Update `STRIPE_WEBHOOK_SECRET` with this value
9. Deploy

### Step 5: Test the flow
1. Use Stripe's test mode
2. Complete a test purchase using Stripe's test card (4242 4242 4242 4242)
3. Check your Cloudflare KV namespace — a license key should appear
4. The license key format will be like: `SP-A3BK9-X7FH2-M4PN8-Y6WT5`

---

## Part 3: Set Up the GitHub Repo (Auto-builds Installers)

### Step 1: Create the repository
1. Go to https://github.com/new
2. Repository name: `sitepilot-desktop`
3. Set to **Public**
4. Click **Create repository**

### Step 2: Upload the code
1. On the repo page, click **uploading an existing file**
2. Drag and drop ALL files from the `sitepilot-desktop-repo.zip`:
   - `package.json`
   - `package-lock.json`
   - `.gitignore`
   - `README.md`
   - `src/` folder (with all 4 files inside)
   - `.github/` folder (with the workflow file inside)
3. Commit the files

### Step 3: Enable Actions permissions
1. Go to repo **Settings** > **Actions** > **General**
2. Under "Workflow permissions", select **Read and write permissions**
3. Click **Save**

### Step 4: Update the license API URL in the app
Before creating a release, you need to update one line in `src/index.html`:

1. Open `src/index.html` in GitHub (click the file)
2. Click the pencil icon to edit
3. Find this line near the top of the `<script>`:
   ```
   const LICENSE_API = 'https://sitepilot-api.YOUR-SUBDOMAIN.workers.dev';
   ```
4. Replace `YOUR-SUBDOMAIN` with your actual Cloudflare Workers subdomain
5. Commit the change

### Step 5: Create your first release
1. On your repo page, click **Releases** (right sidebar)
2. Click **Create a new release**
3. Click **Choose a tag**, type `v1.0.0`, click **Create new tag: v1.0.0 on publish**
4. Release title: `SitePilot v1.0.0`
5. Description: `First release of SitePilot Desktop`
6. Click **Publish release**
7. Wait ~5 minutes for GitHub Actions to build
8. Refresh the release page — you'll see:
   - `SitePilot-Setup-1.0.0.exe` (Windows)
   - `SitePilot-1.0.0.dmg` (Mac)
   - `SitePilot-1.0.0.AppImage` (Linux)

---

## Part 4: How It All Works Together

### Customer journey:
1. Customer visits your site, clicks "Buy SitePilot"
2. Stripe Payment Link handles the purchase
3. Stripe sends webhook to your Cloudflare Worker
4. Worker generates a license key (e.g., `SP-A3BK9-X7FH2-M4PN8-Y6WT5`)
5. Customer receives the key (via Stripe receipt email — see "Delivering Keys" below)
6. Customer downloads SitePilot Desktop from your GitHub Releases page
7. Opens the app, enters their license key
8. App validates against your Cloudflare Worker
9. Customer enters their WordPress URL, connects, done

### Delivering license keys to customers:
**Option A (simplest):** After Stripe checkout, redirect to a "thank you" page that displays the key. You'll need a small page that calls your admin API to look up the key by email.

**Option B:** Use Stripe's post-checkout redirect URL with metadata. The thank-you page calls your API to look up the customer's license.

**Option C (best UX):** Set up a simple email via Stripe's receipt customization or a tool like Zapier to email the license key after purchase.

---

## Admin Commands

You can manage licenses using your admin API. Use any API tool (like Postman, or even Claude) with your admin secret:

**Look up a license:**
```
GET https://sitepilot-api.YOUR-SUBDOMAIN.workers.dev/api/license/SP-XXXXX-XXXXX-XXXXX-XXXXX
Header: Authorization: Bearer YOUR_ADMIN_SECRET
```

**Look up by email:**
```
POST https://sitepilot-api.YOUR-SUBDOMAIN.workers.dev/api/license/lookup
Header: Authorization: Bearer YOUR_ADMIN_SECRET
Body: {"email": "customer@example.com"}
```

**Create a license manually (for giveaways, partners, etc.):**
```
POST https://sitepilot-api.YOUR-SUBDOMAIN.workers.dev/api/license/create
Header: Authorization: Bearer YOUR_ADMIN_SECRET
Body: {"email": "partner@example.com", "plan": "unlimited"}
```

**Deactivate a site (so customer can move their license):**
```
POST https://sitepilot-api.YOUR-SUBDOMAIN.workers.dev/api/license/deactivate
Header: Authorization: Bearer YOUR_ADMIN_SECRET
Body: {"license_key": "SP-XXXXX-XXXXX-XXXXX-XXXXX"}
```
